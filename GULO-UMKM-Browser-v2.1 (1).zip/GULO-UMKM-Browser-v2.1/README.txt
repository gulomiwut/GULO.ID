GULO - GERAKAN UMKM LOKAL
Browser Edition v2.1
Dikembangkan oleh MIWUT

CARA MENJALANKAN
1. Ekstrak folder ZIP.
2. Buka index.html menggunakan Chrome atau Microsoft Edge versi terbaru.
3. Untuk penggunaan Browser Edition, data tersimpan secara lokal pada browser/perangkat yang digunakan.

CATATAN KOMPATIBILITAS
Salt autentikasi internal versi sebelumnya dipertahankan agar hash akun Administrator yang sudah tersimpan tetap dapat diverifikasi. Branding publik aplikasi telah diperbarui dari GFLM menjadi MIWUT.

BATASAN KEAMANAN
Browser Edition adalah aplikasi statis. Data localStorage dapat diubah oleh pengguna yang menguasai perangkat/browser. Jangan gunakan versi lokal ini sebagai sistem autentikasi atau lisensi produksi. Untuk produksi, gunakan backend, database server, HTTPS, kontrol akses sisi server, dan audit log.
